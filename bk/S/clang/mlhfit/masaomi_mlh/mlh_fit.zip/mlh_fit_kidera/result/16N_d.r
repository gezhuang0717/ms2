 output file : result/16N_d.r                result/16N_d.s                
Data file name : data/16N_d.dat                                    
 Number of points of data =          244
 Number of parameters =            5
 Number of free parameters =            5
 Fitting region :           54 ->          231
 Initial value of free parameters
  AAI( 1) =  0.8461020000D+02
  AAI( 2) =  0.3311570000D+01
  AAI( 3) =  0.1308840000D+03
  AAI( 4) =  0.8638910000D+00
  AAI( 5) =  0.3823500000D-01
 ���� �������W��������� ����

 Fitting region(ch) :           54 -->          231
 Fitting region (arb.) :    53.0000000000000      -->    230.000000000000     
 Free parameters 
  AA( 1) =  0.8674834182D+02 +-  0.3517778146D+01
  AA( 2) =  0.3291039341D+01 +-  0.5823112224D-02
  AA( 3) =  0.1309139804D+03 +-  0.8911023887D-02
  AA( 4) =  0.2618210140D+01 +-  0.5567545090D+00
  AA( 5) =  0.3415792910D-01 +-  0.3988857443D-02
 chisq =    217.705558717177     
 reduced chisq =    1.25841363420333     

 output file : result/28si_f_b.r             result/28si_f_b.s             
Data file name : data/28si_f.dat                                   
 Number of points of data =         1187
 Number of parameters =            2
 Number of free parameters =            2
 Fitting region :          638 ->          827
 Initial value of free parameters
  AAI( 1) =  0.1203940000D+03
  AAI( 2) = -0.3493700000D-01
 ���� �������W��������� ����

 Fitting region(ch) :          638 -->          827
 Fitting region (arb.) :    637.000000000000      -->    826.000000000000     
 Free parameters 
  AA( 1) =  0.1110180454D+03 +-  0.9526207656D+01
  AA( 2) = -0.2054486911D-01 +-  0.1297515227D-01
 chisq =    178.143152915504     
 reduced chisq =   0.947569962316512     

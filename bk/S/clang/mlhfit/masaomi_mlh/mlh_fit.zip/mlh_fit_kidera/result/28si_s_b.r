 output file : result/28si_s_b.r             result/28si_s_b.s             
Data file name : data/28si_s.dat                                   
 Number of points of data =         1331
 Number of parameters =            2
 Number of free parameters =            2
 Fitting region :          795 ->          874
 Initial value of free parameters
  AAI( 1) =  0.1051350000D+03
  AAI( 2) =  0.4038180000D-01
 ���� �������W��������� ����

 Fitting region(ch) :          795 -->          874
 Fitting region (arb.) :    794.000000000000      -->    873.000000000000     
 Free parameters 
  AA( 1) =  0.1269269623D+03 +-  0.4742898303D+02
  AA( 2) =  0.1671930135D-01 +-  0.5688553226D-01
 chisq =    87.9930591058319     
 reduced chisq =    1.12811614238246     

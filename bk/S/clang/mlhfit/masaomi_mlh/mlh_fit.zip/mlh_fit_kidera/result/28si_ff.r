 output file : result/28si_ff.r              result/28si_ff.s              
Data file name : data/28si_ff.dat                                  
 Number of points of data =          184
 Number of parameters =            5
 Number of free parameters =            5
 Fitting region :            4 ->          154
 Initial value of free parameters
  AAI( 1) =  0.3586080000D+04
  AAI( 2) =  0.2863070000D+01
  AAI( 3) =  0.1236900000D+03
  AAI( 4) =  0.1548770000D+04
  AAI( 5) =  0.2380200000D+01
 ���� �������W��������� ����

 Fitting region(ch) :            4 -->          154
 Fitting region (arb.) :    3.00000000000000      -->    153.000000000000     
 Free parameters 
  AA( 1) =  0.3584801428D+04 +-  0.3173991962D+02
  AA( 2) =  0.2863827946D+01 +-  0.6024589653D-02
  AA( 3) =  0.1236903380D+03 +-  0.6222997921D-02
  AA( 4) =  0.1547379042D+04 +-  0.6885683168D+01
  AA( 5) =  0.2420791373D+01 +-  0.8268509849D-01
 chisq =    271.911520999038     
 reduced chisq =    1.86240767807560     

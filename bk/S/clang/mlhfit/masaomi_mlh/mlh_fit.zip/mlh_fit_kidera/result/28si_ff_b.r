 output file : result/28si_ff_b.r            result/28si_ff_b.s            
Data file name : data/28si_ff.dat                                  
 Number of points of data =          184
 Number of parameters =            2
 Number of free parameters =            2
 Fitting region :            4 ->          107
 Initial value of free parameters
  AAI( 1) =  0.1548770000D+04
  AAI( 2) =  0.2380200000D+01
 ���� �������W��������� ����

 Fitting region(ch) :            4 -->          107
 Fitting region (arb.) :    3.00000000000000      -->    106.000000000000     
 Free parameters 
  AA( 1) =  0.1518423186D+04 +-  0.8139440266D+01
  AA( 2) =  0.3079567503D+01 +-  0.1339123709D+00
 chisq =    138.402307837122     
 reduced chisq =    1.35688537095218     

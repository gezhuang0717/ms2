 output file : result/28si_f.r               result/28si_f.s               
Data file name : data/28si_f.dat                                   
 Number of points of data =         1187
 Number of parameters =            5
 Number of free parameters =            5
 Fitting region :          518 ->          827
 Initial value of free parameters
  AAI( 1) =  0.5207500000D+03
  AAI( 2) =  0.7488460000D+01
  AAI( 3) =  0.6074380000D+03
  AAI( 4) =  0.1203940000D+03
  AAI( 5) = -0.3493700000D-01
 ���� �������W��������� ����

 �ɂ��K��l��10�{���z�����܂܎������܂���
 Fitting region(ch) :          518 -->          827
 Fitting region (arb.) :    517.000000000000      -->    826.000000000000     
 Free parameters 
  AA( 1) =  0.5293141315D+03 +-  0.6209962276D+01
  AA( 2) =  0.7669276664D+01 +-  0.2729518445D-03
  AA( 3) =  0.6074914784D+03 +-  0.3031235670D-03
  AA( 4) =  0.1237755797D+03 +-  0.4447086431D+01
  AA( 5) = -0.3797938267D-01 +-  0.6454512236D-02
 chisq =    782.888885310634     
 reduced chisq =    2.56684880429716     

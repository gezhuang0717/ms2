 output file : result/16N_d_b.r              result/16N_d_b.s              
Data file name : data/16N_d.dat                                    
 Number of points of data =          244
 Number of parameters =            2
 Number of free parameters =            2
 Fitting region :          153 ->          231
 Initial value of free parameters
  AAI( 1) =  0.8638910000D+00
  AAI( 2) =  0.3823500000D-01
 ���� �������W��������� ����

 Fitting region(ch) :          153 -->          231
 Fitting region (arb.) :    152.000000000000      -->    230.000000000000     
 Free parameters 
  AA( 1) =  0.1311452943D+02 +-  0.2808649828D+01
  AA( 2) = -0.2008402314D-01 +-  0.1450360968D-01
 chisq =    75.0704245894942     
 reduced chisq =   0.974940579084341     

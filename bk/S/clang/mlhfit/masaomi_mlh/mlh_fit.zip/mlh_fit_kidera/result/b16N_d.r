 output file : result/b16N_d.r               result/b16N_d.s               
Data file name : data/b16N_d.dat                                   
 Number of points of data =          244
 Number of parameters =            5
 Number of free parameters =            5
 Fitting region :           54 ->          231
 Initial value of free parameters
  AAI( 1) =  0.1187470000D+02
  AAI( 2) =  0.3126750000D+01
  AAI( 3) =  0.1321130000D+03
  AAI( 4) =  0.1180990000D+01
  AAI( 5) =  0.2982380000D-02
 ���� �������W��������� ����

 Fitting region(ch) :           54 -->          231
 Fitting region (arb.) :    53.0000000000000      -->    230.000000000000     
 Free parameters 
  AA( 1) =  0.1112814560D+02 +-  0.1289728970D+01
  AA( 2) =  0.3455638128D+01 +-  0.5698569813D-01
  AA( 3) =  0.1318870365D+03 +-  0.2576679209D+00
  AA( 4) =  0.1094222613D+01 +-  0.3013579800D+00
  AA( 5) =  0.3447666453D-02 +-  0.2071394387D-02
 chisq =    118.524572187140     
 reduced chisq =   0.685113134029709     

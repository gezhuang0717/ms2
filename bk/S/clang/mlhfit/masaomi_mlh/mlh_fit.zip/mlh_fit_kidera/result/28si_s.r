 output file : result/28si_s.r               result/28si_s.s               
Data file name : data/28si_s.dat                                   
 Number of points of data =         1331
 Number of parameters =            5
 Number of free parameters =            5
 Fitting region :          668 ->          874
 Initial value of free parameters
  AAI( 1) =  0.4941990000D+03
  AAI( 2) =  0.8586500000D+01
  AAI( 3) =  0.7664160000D+03
  AAI( 4) =  0.1051350000D+03
  AAI( 5) =  0.4038180000D-01
 ���� �������W��������� ����

 �ɂ��K��l��10�{���z�����܂܎������܂���
 Fitting region(ch) :          668 -->          874
 Fitting region (arb.) :    667.000000000000      -->    873.000000000000     
 Free parameters 
  AA( 1) =  0.4974761734D+03 +-  0.6003488084D+01
  AA( 2) =  0.8638830378D+01 +-  0.3899181740D-03
  AA( 3) =  0.7664717755D+03 +-  0.4206113053D-03
  AA( 4) =  0.1052199247D+03 +-  0.1061406704D+02
  AA( 5) =  0.4221694662D-01 +-  0.1374212753D-01
 chisq =    389.334608207746     
 reduced chisq =    1.92739905053340     

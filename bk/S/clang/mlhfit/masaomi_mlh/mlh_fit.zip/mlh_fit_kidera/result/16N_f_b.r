 output file : result/16N_f_b.r              result/16N_f_b.s              
Data file name : data/16N_f.dat                                    
 Number of points of data =          733
 Number of parameters =            2
 Number of free parameters =            2
 Fitting region :          193 ->          533
 Initial value of free parameters
  AAI( 1) =  0.5587500000D+00
  AAI( 2) =  0.1662900000D-03
 ���� �������W��������� ����

 Fitting region(ch) :          193 -->          533
 Fitting region (arb.) :    192.000000000000      -->    532.000000000000     
 Free parameters 
  AA( 1) =  0.1061885866D+01 +-  0.1765198056D+00
  AA( 2) = -0.1086365098D-02 +-  0.4530044759D-03
 chisq =    221.759202355614     
 reduced chisq =   0.654156939102107     

 output file : result/b16N_s.r               result/b16N_s.s               
Data file name : data/b16N_s.dat                                   
 Number of points of data =          424
 Number of parameters =            5
 Number of free parameters =            5
 Fitting region :           88 ->          408
 Initial value of free parameters
  AAI( 1) =  0.2483840000D+02
  AAI( 2) =  0.2606120000D+01
  AAI( 3) =  0.1935510000D+03
  AAI( 4) =  0.8663930000D+00
  AAI( 5) =  0.3600050000D-02
 ���� �������W��������� ����

 Fitting region(ch) :           88 -->          408
 Fitting region (arb.) :    87.0000000000000      -->    407.000000000000     
 Free parameters 
  AA( 1) =  0.2482676886D+02 +-  0.2046139593D+01
  AA( 2) =  0.2650017354D+01 +-  0.1442684962D-01
  AA( 3) =  0.1932602545D+03 +-  0.1744239250D-01
  AA( 4) =  0.1320445889D+01 +-  0.2104794595D+00
  AA( 5) =  0.6082001540D-03 +-  0.8070727173D-03
 chisq =    217.152262841089     
 reduced chisq =   0.687190705193320     

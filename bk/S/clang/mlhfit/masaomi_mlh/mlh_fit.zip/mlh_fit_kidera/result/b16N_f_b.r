 output file : result/b16N_f_b.r             result/b16N_f_b.s             
Data file name : data/b16N_f.dat                                   
 Number of points of data =          733
 Number of parameters =            2
 Number of free parameters =            2
 Fitting region :          193 ->          533
 Initial value of free parameters
  AAI( 1) =  0.1359500000D+01
  AAI( 2) =  0.2485190000D-02
 ���� �������W��������� ����

 Fitting region(ch) :          193 -->          533
 Fitting region (arb.) :    192.000000000000      -->    532.000000000000     
 Free parameters 
  AA( 1) =  0.3337682813D+00 +-  0.1132174655D+00
  AA( 2) = -0.1470313129D-04 +-  0.3003791914D-03
 chisq =    246.123315274347     
 reduced chisq =   0.726027478685390     

 output file : result/b16N_d_b.r             result/b16N_d_b.s             
Data file name : data/b16N_d.dat                                   
 Number of points of data =          244
 Number of parameters =            2
 Number of free parameters =            2
 Fitting region :          153 ->          231
 Initial value of free parameters
  AAI( 1) =  0.1180990000D+01
  AAI( 2) =  0.2982380000D-02
 ���� �������W��������� ����

 Fitting region(ch) :          153 -->          231
 Fitting region (arb.) :    152.000000000000      -->    230.000000000000     
 Free parameters 
  AA( 1) =  0.3449965556D+01 +-  0.1165855138D+01
  AA( 2) = -0.8983185031D-02 +-  0.5955319390D-02
 chisq =    59.9236061586950     
 reduced chisq =   0.778228651411623     

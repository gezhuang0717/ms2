 output file : result/b16N_f.r               result/b16N_f.s               
Data file name : data/b16N_f.dat                                   
 Number of points of data =          733
 Number of parameters =            5
 Number of free parameters =            5
 Fitting region :          139 ->          533
 Initial value of free parameters
  AAI( 1) =  0.2187250000D+02
  AAI( 2) =  0.2774890000D+01
  AAI( 3) =  0.1697410000D+03
  AAI( 4) =  0.6290830000D+00
  AAI( 5) = -0.1014220000D-02
 ���� �������W��������� ����

 Fitting region(ch) :          139 -->          533
 Fitting region (arb.) :    138.000000000000      -->    532.000000000000     
 Free parameters 
  AA( 1) =  0.2063908196D+02 +-  0.1680514511D+01
  AA( 2) =  0.3058112223D+01 +-  0.8897554076D-02
  AA( 3) =  0.1692365359D+03 +-  0.1302560794D-01
  AA( 4) =  0.3120584534D+00 +-  0.9680168844D-01
  AA( 5) =  0.4176825630D-04 +-  0.2690042396D-03
 chisq =    289.530058402967     
 reduced chisq =   0.742384765135812     

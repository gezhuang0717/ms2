 output file : result/28si_d_b.r             result/28si_d_b.s             
Data file name : data/28si_d.dat                                   
 Number of points of data =          903
 Number of parameters =            2
 Number of free parameters =            2
 Fitting region :          534 ->          595
 Initial value of free parameters
  AAI( 1) =  0.8310320000D+02
  AAI( 2) =  0.9379330000D-01
 ���� �������W��������� ����

 Fitting region(ch) :          534 -->          595
 Fitting region (arb.) :    533.000000000000      -->    594.000000000000     
 Free parameters 
  AA( 1) =  0.1784349918D+03 +-  0.4632155827D+02
  AA( 2) = -0.7198584570D-01 +-  0.8213560808D-01
 chisq =    60.4531982528587     
 reduced chisq =    1.00755330421431     

 output file : result/28si_d.r               result/28si_d.s               
Data file name : data/28si_d.dat                                   
 Number of points of data =          903
 Number of parameters =            5
 Number of free parameters =            5
 Fitting region :          406 ->          595
 Initial value of free parameters
  AAI( 1) =  0.3687280000D+03
  AAI( 2) =  0.8893740000D+01
  AAI( 3) =  0.4984040000D+03
  AAI( 4) =  0.8310320000D+02
  AAI( 5) =  0.9379330000D-01
 ���� �������W��������� ����

 �ɂ��K��l��10�{���z�����܂܎������܂���
 Fitting region(ch) :          406 -->          595
 Fitting region (arb.) :    405.000000000000      -->    594.000000000000     
 Free parameters 
  AA( 1) =  0.3724228194D+03 +-  0.5355943768D+01
  AA( 2) =  0.8925525214D+01 +-  0.4464897868D-03
  AA( 3) =  0.4985147030D+03 +-  0.4833425718D-03
  AA( 4) =  0.8503430154D+02 +-  0.7665365065D+01
  AA( 5) =  0.9251648174D-01 +-  0.1530118448D-01
 chisq =    335.756687256173     
 reduced chisq =    1.81490101219553     

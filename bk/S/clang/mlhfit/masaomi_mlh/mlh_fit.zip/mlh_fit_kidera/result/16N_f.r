 output file : result/16N_f.r                result/16N_f.s                
Data file name : data/16N_f.dat                                    
 Number of points of data =          733
 Number of parameters =            5
 Number of free parameters =            5
 Fitting region :          139 ->          533
 Initial value of free parameters
  AAI( 1) =  0.1578070000D+03
  AAI( 2) =  0.2423420000D+01
  AAI( 3) =  0.1702160000D+03
  AAI( 4) =  0.5587500000D+00
  AAI( 5) =  0.1662900000D-03
 ���� �������W��������� ����

 Fitting region(ch) :          139 -->          533
 Fitting region (arb.) :    138.000000000000      -->    532.000000000000     
 Free parameters 
  AA( 1) =  0.1470355645D+03 +-  0.4716663678D+01
  AA( 2) =  0.2707202559D+01 +-  0.4388040829D-02
  AA( 3) =  0.1698458067D+03 +-  0.7214945193D-02
  AA( 4) =  0.1343123985D+01 +-  0.1489375161D+00
  AA( 5) = -0.1748044838D-02 +-  0.3777216107D-03
 chisq =    361.771395840852     
 reduced chisq =   0.927618963694493     

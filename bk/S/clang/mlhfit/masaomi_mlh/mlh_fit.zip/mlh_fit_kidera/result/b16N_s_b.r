 output file : result/b16N_s_b.r             result/b16N_s_b.s             
Data file name : data/b16N_s.dat                                   
 Number of points of data =          424
 Number of parameters =            2
 Number of free parameters =            2
 Fitting region :          227 ->          408
 Initial value of free parameters
  AAI( 1) =  0.8663930000D+00
  AAI( 2) =  0.3600050000D-02
 ���� �������W��������� ����

 Fitting region(ch) :          227 -->          408
 Fitting region (arb.) :    226.000000000000      -->    407.000000000000     
 Free parameters 
  AA( 1) =  0.2276226496D+01 +-  0.5395307753D+00
  AA( 2) = -0.2348371132D-02 +-  0.1655387740D-02
 chisq =    122.004464226104     
 reduced chisq =   0.677802579033909     

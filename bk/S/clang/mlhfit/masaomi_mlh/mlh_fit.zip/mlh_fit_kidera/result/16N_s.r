 output file : result/16N_s.r                result/16N_s.s                
Data file name : data/16N_s.dat                                    
 Number of points of data =          424
 Number of parameters =            5
 Number of free parameters =            5
 Fitting region :           88 ->          408
 Initial value of free parameters
  AAI( 1) =  0.1230960000D+03
  AAI( 2) =  0.3023520000D+01
  AAI( 3) =  0.1931840000D+03
  AAI( 4) =  0.5420360000D+01
  AAI( 5) =  0.5115720000D-02
 ���� �������W��������� ����

 �ɂ��K��l��10�{���z�����܂܎������܂���
 Fitting region(ch) :           88 -->          408
 Fitting region (arb.) :    87.0000000000000      -->    407.000000000000     
 Free parameters 
  AA( 1) =  0.1211458979D+03 +-  0.4141396900D+01
  AA( 2) =  0.3192758539D+01 +-  0.4190348192D-02
  AA( 3) =  0.1931923124D+03 +-  0.5202975320D-02
  AA( 4) =  0.6478022334D+01 +-  0.4421842193D+00
  AA( 5) =  0.5852372817D-02 +-  0.1693243249D-02
 chisq =    353.420875525962     
 reduced chisq =    1.11842049217076     

 output file : result/16N_s_b.r              result/16N_s_b.s              
Data file name : data/16N_s.dat                                    
 Number of points of data =          424
 Number of parameters =            2
 Number of free parameters =            2
 Fitting region :          227 ->          408
 Initial value of free parameters
  AAI( 1) =  0.5420360000D+01
  AAI( 2) =  0.5115720000D-02
 ���� �������W��������� ����

 Fitting region(ch) :          227 -->          408
 Fitting region (arb.) :    226.000000000000      -->    407.000000000000     
 Free parameters 
  AA( 1) =  0.5362655788D+01 +-  0.1253756063D+01
  AA( 2) =  0.9061969803D-02 +-  0.3944006350D-02
 chisq =    158.015053022866     
 reduced chisq =   0.877861405682587     
